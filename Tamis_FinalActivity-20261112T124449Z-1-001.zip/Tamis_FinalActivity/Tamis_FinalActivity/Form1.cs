﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Tamis_FinalActivity
{
    public partial class Form1 : Form
    {
        private string connStr =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\InventoryDB.accdb;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtUser.Focus();
        }

        private void chkShowPass_CheckedChanged(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar = !chkShowPass.Checked;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text.Trim();
            string password = txtPass.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.",
                                "Input Required",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    string query = "SELECT PasswordHash FROM Users WHERE Username = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", username);
                        object result = cmd.ExecuteScalar();

                        if (result == null || result == DBNull.Value)
                        {
                            MessageBox.Show("User not found.", "Login Failed",
                                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        string storedHash = result.ToString().Trim();
                        bool verified = false;

                        if (storedHash.Split('.').Length == 3)
                        {
                            verified = PasswordHasher.Verify(password, storedHash);
                        }
                        else
                        {
                            if (storedHash == password)
                            {
                                verified = true;

                                string newHash = PasswordHasher.Hash(password);
                                using (OleDbCommand upd = new OleDbCommand(
                                    "UPDATE Users SET PasswordHash = ? WHERE Username = ?", conn))
                                {
                                    upd.Parameters.AddWithValue("?", newHash);
                                    upd.Parameters.AddWithValue("?", username);
                                    upd.ExecuteNonQuery();
                                }
                            }
                        }

                        if (verified)
                        {
                            MessageBox.Show("Login Successful!", "Welcome",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Main dash = new Main(username);
                            dash.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid password.", "Login Failed",
                                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtPass.Clear();
                            txtPass.Focus();
                        }
                    }
                }
            }
            catch (OleDbException dbEx)
            {
                MessageBox.Show("Database error:\n" + dbEx.Message,
                                "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected error:\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnLogin_Click(sender, EventArgs.Empty);
            }
        }

        private void lnkSignup_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup signup = new Signup();
            signup.Show();
        }
    }
}