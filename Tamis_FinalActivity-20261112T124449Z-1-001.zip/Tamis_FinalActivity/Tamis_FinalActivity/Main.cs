﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Tamis_FinalActivity
{
    public partial class Main : Form
    {
        private string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\InventoryDB.accdb;";
        private string _loggedUser;

        public Main() : this("admin") { }

        public Main(string username)
        {
            InitializeComponent();
            _loggedUser = username;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            lblLoggedUser.Text = "👤 " + _loggedUser;
            StyleGrid();
            SetupGridButtons();
            RefreshDashboard();
        }

        private void pnlHeader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void StyleGrid()
        {
            dgvProducts.AllowUserToAddRows = false;
            dgvProducts.AllowUserToDeleteRows = false;
            dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProducts.MultiSelect = false;
            dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvProducts.RowHeadersVisible = false;
            dgvProducts.BorderStyle = BorderStyle.None;
            dgvProducts.BackgroundColor = Color.White;
            dgvProducts.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvProducts.GridColor = Color.FromArgb(224, 224, 224);
            dgvProducts.EnableHeadersVisualStyles = false;
            dgvProducts.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            dgvProducts.DefaultCellStyle.BackColor = Color.White;
            dgvProducts.DefaultCellStyle.ForeColor = Color.FromArgb(0x33, 0x33, 0x33);
            dgvProducts.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0xFF, 0xE5, 0xE9);
            dgvProducts.DefaultCellStyle.SelectionForeColor = Color.FromArgb(0x33, 0x33, 0x33);
            dgvProducts.DefaultCellStyle.Padding = new Padding(5);
            dgvProducts.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(0xF7, 0xF7, 0xF7);
            dgvProducts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dgvProducts.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(0x1F, 0x3A, 0x5F);
            dgvProducts.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvProducts.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(0x1F, 0x3A, 0x5F);
            dgvProducts.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White;
            dgvProducts.ColumnHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleLeft;
            dgvProducts.ColumnHeadersDefaultCellStyle.Padding = new Padding(5);
            dgvProducts.ColumnHeadersHeight = 40;
            dgvProducts.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvProducts.RowTemplate.Height = 40;
            dgvProducts.RowTemplate.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(0xFF, 0xE5, 0xE9);
            foreach (DataGridViewColumn col in dgvProducts.Columns)
            {
                if (col.Name != "Edit" && col.Name != "Delete")
                    col.ReadOnly = true;
            }
            dgvProducts.ReadOnly = false;
            dgvProducts.CellMouseEnter += dgvProducts_CellMouseEnter;
            dgvProducts.CellMouseLeave += dgvProducts_CellMouseLeave;
            dgvProducts.MouseLeave += dgvProducts_MouseLeave;
        }
        private void SetupGridButtons()
        {
            if (dgvProducts.Columns.Contains("Edit")) dgvProducts.Columns.Remove("Edit");
            if (dgvProducts.Columns.Contains("Delete")) dgvProducts.Columns.Remove("Delete");

            var btnEdit = new DataGridViewButtonColumn
            {
                Name = "Edit",
                HeaderText = "Edit",
                Text = "Edit",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Flat,
                Width = 80,
                MinimumWidth = 80,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.None,  
                ReadOnly = false,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(0x28, 0xA7, 0x45),
                    ForeColor = Color.White,
                    SelectionBackColor = Color.FromArgb(0x1E, 0x7E, 0x34),
                    SelectionForeColor = Color.White,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                }
            };

            var btnDelete = new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "Delete",
                Text = "Delete",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Flat,
                Width = 90,
                MinimumWidth = 90,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.None,
                ReadOnly = false,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(0xDC, 0x35, 0x45),
                    ForeColor = Color.White,
                    SelectionBackColor = Color.FromArgb(0xB0, 0x2A, 0x37),
                    SelectionForeColor = Color.White,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                }
            };

            dgvProducts.Columns.Add(btnEdit);
            dgvProducts.Columns.Add(btnDelete);

            int colCount = dgvProducts.Columns.Count;
            dgvProducts.Columns["Edit"].DisplayIndex = colCount - 2;
            dgvProducts.Columns["Delete"].DisplayIndex = colCount - 1;

            foreach (DataGridViewColumn col in dgvProducts.Columns)
            {
                if (col.Name != "Edit" && col.Name != "Delete")
                {
                    col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    col.ReadOnly = true;
                }
            }
            dgvProducts.ReadOnly = false;
        }
        private void RefreshDashboard()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    string query = "SELECT ID, ProductName, Description, Category, UnitPrice, Quantity " +
                                   "FROM Products ORDER BY ProductName";

                    OleDbDataAdapter da = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvProducts.DataSource = dt;

                    if (dgvProducts.Columns.Contains("ID"))
                        dgvProducts.Columns["ID"].Visible = false;

                    if (dgvProducts.Columns.Contains("ProductName"))
                        dgvProducts.Columns["ProductName"].HeaderText = "Product Name";
                    if (dgvProducts.Columns.Contains("Description"))
                        dgvProducts.Columns["Description"].HeaderText = "Description";
                    if (dgvProducts.Columns.Contains("Category"))
                        dgvProducts.Columns["Category"].HeaderText = "Category";
                    if (dgvProducts.Columns.Contains("UnitPrice"))
                    {
                        dgvProducts.Columns["UnitPrice"].HeaderText = "Unit Price";
                        dgvProducts.Columns["UnitPrice"].DefaultCellStyle.Format = "₱#,##0.00";
                        dgvProducts.Columns["UnitPrice"].DefaultCellStyle.Alignment =
                            DataGridViewContentAlignment.MiddleRight;
                    }
                    if (dgvProducts.Columns.Contains("Quantity"))
                    {
                        dgvProducts.Columns["Quantity"].HeaderText = "Quantity";
                        dgvProducts.Columns["Quantity"].DefaultCellStyle.Alignment =
                            DataGridViewContentAlignment.MiddleCenter;
                    }

                    SetupGridButtons();                          

                    int total = dt.Rows.Count;
                    int inStock = 0, lowStock = 0, outStock = 0;
                    foreach (DataRow r in dt.Rows)
                    {
                        int q = Convert.ToInt32(r["Quantity"]);
                        if (q == 0) outStock++;
                        else if (q <= 10) lowStock++;
                        else inStock++;
                    }

                    lblTotal.Text = total.ToString();
                    lblInStock.Text = inStock.ToString();
                    lblLowStock.Text = lowStock.ToString();
                    lblOutStock.Text = outStock.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products:\n" + ex.Message,
                                "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            RefreshDashboard();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string term = txtSearch.Text.Trim();
            if (string.IsNullOrEmpty(term))
            {
                RefreshDashboard();
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    string query =
                        "SELECT ID, ProductName, Description, Category, UnitPrice, Quantity " +
                        "FROM Products " +
                        "WHERE ProductName LIKE ? OR Category LIKE ? OR Description LIKE ? " +
                        "ORDER BY ProductName";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        string like = "%" + term + "%";
                        cmd.Parameters.AddWithValue("?", like);
                        cmd.Parameters.AddWithValue("?", like);
                        cmd.Parameters.AddWithValue("?", like);

                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvProducts.DataSource = dt;

                        if (dgvProducts.Columns.Contains("ID"))
                            dgvProducts.Columns["ID"].Visible = false;

                        SetupGridButtons();                         

                        if (dt.Rows.Count == 0)
                            MessageBox.Show("No products match \"" + term + "\".",
                                            "No Results",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Search error:\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (var form = new ProductForm())
            {
                form.IsEditMode = false;
                if (form.ShowDialog(this) == DialogResult.OK)
                    RefreshDashboard();
            }
        }
        private void DeleteProduct(int id)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "DELETE FROM Products WHERE ID = ?", conn))
                    {
                        cmd.Parameters.AddWithValue("?", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Product deleted.", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error:\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dgvProducts_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvProducts.Columns[e.ColumnIndex].Name == "Quantity" && e.Value != null)
            {
                int qty;
                if (int.TryParse(e.Value.ToString(), out qty))
                {
                    if (qty == 0)
                        e.CellStyle.ForeColor = Color.FromArgb(0xDC, 0x35, 0x45);
                    else if (qty <= 10)
                        e.CellStyle.ForeColor = Color.FromArgb(0xFF, 0xA5, 0x00);
                    else
                        e.CellStyle.ForeColor = Color.FromArgb(0x28, 0xA7, 0x45);

                    e.CellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Log out?", "Confirm",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                var login = new Form1();
                login.Show();
                this.Close();
            }
        }

        private void dgvProducts_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string colName = dgvProducts.Columns[e.ColumnIndex].Name;
            if (colName != "Edit" && colName != "Delete") return;

            e.PaintBackground(e.CellBounds, true);

            Color btnColor = colName == "Edit"
                ? Color.FromArgb(0x28, 0xA7, 0x45)  
                : Color.FromArgb(0xDC, 0x35, 0x45); 

            const int btnW = 68;
            const int btnH = 28;
            int x = e.CellBounds.X + (e.CellBounds.Width - btnW) / 2;
            int y = e.CellBounds.Y + (e.CellBounds.Height - btnH) / 2;
            Rectangle btnRect = new Rectangle(x, y, btnW, btnH);

            using (var path = RoundedRect(btnRect, 4))
            using (var brush = new SolidBrush(btnColor))
                e.Graphics.FillPath(brush, path);

            TextRenderer.DrawText(
                e.Graphics, colName, new Font("Segoe UI", 9F, FontStyle.Bold),
                btnRect, Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            e.Handled = true;
        }
        private static System.Drawing.Drawing2D.GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void dgvProducts_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            string colName = dgvProducts.Columns[e.ColumnIndex].Name;
            if (colName != "Edit" && colName != "Delete") return;

            int productId = Convert.ToInt32(dgvProducts.Rows[e.RowIndex].Cells["ID"].Value);

            if (colName == "Edit")
            {
                using (var form = new ProductForm())
                {
                    form.IsEditMode = true;
                    form.ProductId = productId;
                    if (form.ShowDialog(this) == DialogResult.OK)
                        RefreshDashboard();
                }
            }
            else if (colName == "Delete")
            {
                if (MessageBox.Show("Delete this product?", "Confirm Delete",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                    == DialogResult.Yes)
                {
                    DeleteProduct(productId);
                    RefreshDashboard();
                }
            }
        }
        private void dgvProducts_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            string colName = dgvProducts.Columns[e.ColumnIndex].Name;
            dgvProducts.Cursor = (colName == "Edit" || colName == "Delete")
                                 ? Cursors.Hand : Cursors.Default;
        }

        private void dgvProducts_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            dgvProducts.Cursor = Cursors.Default;
        }

        private void dgvProducts_MouseLeave(object sender, EventArgs e)
        {
            dgvProducts.Cursor = Cursors.Default;
        }
    }
}
