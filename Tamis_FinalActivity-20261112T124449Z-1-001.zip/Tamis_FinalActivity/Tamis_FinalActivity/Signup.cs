﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Tamis_FinalActivity
{
    public partial class Signup : Form
    {
        private string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\InventoryDB.accdb;";
        public Signup()
        {
            InitializeComponent();
        }

        private void Signup_Load(object sender, EventArgs e)
        {
            txtUser.Focus();
        }

        private void lnkLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Close();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text.Trim();
            string password = txtPass.Text;
            string confirm = txtConfirm.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Username and password are required.",
                                "Input Required",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (username.Length < 4)
            {
                MessageBox.Show("Username must be at least 4 characters.",
                                "Invalid Username",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters.",
                                "Weak Password",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirm)
            {
                MessageBox.Show("Passwords do not match.",
                                "Mismatch",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtConfirm.Clear();
                txtConfirm.Focus();
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Users WHERE Username = ?";
                    using (OleDbCommand checkCmd = new OleDbCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("?", username);
                        int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Username already exists. Please choose another.",
                                            "Duplicate Username",
                                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string hash = PasswordHasher.Hash(password);

                    string insertQuery =
                        "INSERT INTO Users (Username, PasswordHash) VALUES (?, ?)";
                    using (OleDbCommand insertCmd = new OleDbCommand(insertQuery, conn))
                    {
                        insertCmd.Parameters.AddWithValue("?", username);
                        insertCmd.Parameters.AddWithValue("?", hash);
                        insertCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Account created successfully! You can now log in.",
                                "Signup Successful",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                Form1 login = new Form1();
                login.Show();
                this.Hide();
            }
            catch (OleDbException dbEx)
            {
                MessageBox.Show("Database error:\n" + dbEx.Message,
                                "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected error:\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkShowPass_CheckedChanged(object sender, EventArgs e)
        {
            bool show = chkShowPass.Checked;
            txtPass.UseSystemPasswordChar = !show;
            txtConfirm.UseSystemPasswordChar = !show;
        }
        private void txtConfirm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnSignup_Click(sender, EventArgs.Empty);
            }
        }
    }
}
