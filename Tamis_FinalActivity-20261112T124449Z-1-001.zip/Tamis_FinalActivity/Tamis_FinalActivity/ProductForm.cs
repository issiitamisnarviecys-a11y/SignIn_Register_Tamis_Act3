﻿using System;
using System.Data.OleDb;
using System.Globalization;
using System.Windows.Forms;

namespace Tamis_FinalActivity
{
    public partial class ProductForm : Form
    {
        private string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\InventoryDB.accdb;";

        public bool IsEditMode { get; set; } = false;
        public int ProductId { get; set; } = 0;

        public ProductForm()
        {
            InitializeComponent();
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.AddRange(new object[]
            {
                "Action Figure", "Comic Book", "Apparel", "Prop Replica",
                "Collectible", "Poster", "Accessories", "Other"
            });
            cmbCategory.SelectedIndex = 0;

            if (IsEditMode)
            {
                this.Text = "Edit Product";
                if (lblFormTitle != null) lblFormTitle.Text = "Edit Product";
                LoadProduct(ProductId);
            }
            else
            {
                this.Text = "Add New Product";
                if (lblFormTitle != null) lblFormTitle.Text = "Add New Product";
            }

            txtName.Focus();
        }
        private void LoadProduct(int id)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    string query =
                        "SELECT ProductName, Description, Category, UnitPrice, Quantity " +
                        "FROM Products WHERE ID = ?";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", id);

                        using (OleDbDataReader rd = cmd.ExecuteReader())
                        {
                            if (rd.Read())
                            {
                                txtName.Text = rd["ProductName"].ToString();
                                txtDesc.Text = rd["Description"]?.ToString() ?? "";
                                cmbCategory.SelectedItem = rd["Category"].ToString();
                                txtPrice.Text = Convert.ToDecimal(rd["UnitPrice"])
                                                .ToString("0.00", CultureInfo.InvariantCulture);
                                txtQty.Text = rd["Quantity"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Product not found.", "Error",
                                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.DialogResult = DialogResult.Cancel;
                                this.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error:\n" + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string desc = txtDesc.Text.Trim();
            string cat = cmbCategory.SelectedItem?.ToString() ?? "";

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Product name is required.", "Validation",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(cat))
            {
                MessageBox.Show("Please select a category.", "Validation",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbCategory.Focus();
                return;
            }

            decimal price;
            if (!decimal.TryParse(txtPrice.Text.Trim(), NumberStyles.Any,
                                  CultureInfo.InvariantCulture, out price) || price < 0)
            {
                MessageBox.Show("Unit price must be a valid non-negative number.",
                                "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Focus();
                return;
            }

            int qty;
            if (!int.TryParse(txtQty.Text.Trim(), out qty) || qty < 0)
            {
                MessageBox.Show("Quantity must be a valid non-negative whole number.",
                                "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtQty.Focus();
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    conn.Open();

                    if (IsEditMode)
                    {
                        string sql = "UPDATE Products SET ProductName = ?, Description = ?, " +
                                     "Category = ?, UnitPrice = ?, Quantity = ? WHERE ID = ?";

                        using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("?", name);
                            cmd.Parameters.AddWithValue("?", desc);
                            cmd.Parameters.AddWithValue("?", cat);
                            cmd.Parameters.AddWithValue("?", price);
                            cmd.Parameters.AddWithValue("?", qty);
                            cmd.Parameters.AddWithValue("?", ProductId);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        string sql = "INSERT INTO Products " +
                                     "(ProductName, Description, Category, UnitPrice, Quantity) " +
                                     "VALUES (?, ?, ?, ?, ?)";

                        using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("?", name);
                            cmd.Parameters.AddWithValue("?", desc);
                            cmd.Parameters.AddWithValue("?", cat);
                            cmd.Parameters.AddWithValue("?", price);
                            cmd.Parameters.AddWithValue("?", qty);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show(IsEditMode ? "Product updated." : "Product added.",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;   // signals Main.cs to refresh
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save error:\n" + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}